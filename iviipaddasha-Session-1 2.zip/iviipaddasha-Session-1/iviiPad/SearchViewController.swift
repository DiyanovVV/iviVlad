//
//  SearchViewController.swift
//  iviiPad
//
//  Created by WSR on 17/07/2020.
//  Copyright © 2020 WSR. All rights reserved.
//

import UIKit
import AlignedCollectionViewFlowLayout
class SearchViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UICollectionViewDelegate, UITextFieldDelegate {

    @IBOutlet weak var searchTF: UITextField!
    @IBOutlet weak var collView: UICollectionView!
    
    var films = addFilm().add()
    var searchFilm: [Film] = []
    var flag = false
    override func viewDidLoad() {
        super.viewDidLoad()
        collView.collectionViewLayout = AlignedCollectionViewFlowLayout(horizontalAlignment: .justified, verticalAlignment: .top)
        // Do any additional setup after loading the view.
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if flag {
            return searchFilm.count
        } else {
            return 0
        }
       }
       
       
       func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
           let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
           let f = searchFilm[indexPath.row]
           cell.imageFilm.image = UIImage(named: f.image)
           cell.nameFilm.text = f.name
           cell.imageFilm.contentMode = .scaleAspectFill
           return cell
       }
       
       func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
                  return CGSize(width: 170, height: 230)
          }
       
       func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
           let cell = collectionView.cellForItem(at: indexPath) as! CollectionViewCell
           UserDefaults.standard.set(cell.nameFilm.text, forKey: "nameFilm")
           performSegue(withIdentifier: "segFilm", sender: self)
       }
    

    @IBAction func changedSearch(_ sender: Any) {
        if searchTF.text != "" {
            flag = true
            searchFilm = films.filter({
                $0.name.lowercased().prefix(searchTF.text!.count) == searchTF.text!.lowercased() || $0.style.lowercased().prefix(searchTF.text!.count) == searchTF.text!.lowercased() })
        } else {
            flag = false
        }
        collView.reloadData()
    }
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    @IBAction func searchAction(_ sender: Any) {
        self.view.endEditing(true)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
}
