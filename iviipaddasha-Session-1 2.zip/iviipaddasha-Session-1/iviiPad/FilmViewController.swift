//
//  FilmViewController.swift
//  iviiPad
//
//  Created by WSR on 17/07/2020.
//  Copyright © 2020 WSR. All rights reserved.
//

import UIKit
import YouTubePlayer

class FilmViewController: UIViewController {

    @IBOutlet weak var nameFilm: UILabel!
    @IBOutlet weak var videoFilm: YouTubePlayerView!
    @IBOutlet weak var descrFilm: UITextView!
    @IBOutlet weak var styleFilm: UILabel!
    let namefilm = UserDefaults.standard.string(forKey: "nameFilm")
    
    // всплыв окно
    @IBOutlet weak var previewView: UIView!
    @IBOutlet weak var blackView: UIView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let film = addFilm().add().filter({$0.name == namefilm}).first
        nameFilm.text = film?.name
        styleFilm.text = film?.style
        descrFilm.text = film?.description
        if film?.url != "" {
            videoFilm.loadVideoURL(URL(string: film!.url)!)
        }
        
        // Do any additional setup after loading the view.
    }
    

    @IBAction func backAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    
    
    @IBAction func onlineAction(_ sender: Any) {
        blackView.isHidden = false
        previewView.layer.borderColor = UIColor.white.cgColor
        previewView.layer.borderWidth = 1
        let frame = previewView.frame
        UIView.animate(withDuration: 0.5, delay: 0, options: [.curveEaseOut], animations: {
            self.previewView.frame = CGRect(x: frame.origin.x, y: self.view.center.y / 2, width: frame.size.width, height: frame.size.height)
        }, completion: nil)
    }
    
    @IBAction func okAction(_ sender: Any) {
        blackView.isHidden = true
         let frame = previewView.frame
        previewView.frame = CGRect(x: frame.origin.x, y: self.view.frame.size.height, width: frame.size.width, height: frame.size.height)
    }
    
    
}
