//
//  TabBarViewController.swift
//  iviiPad
//
//  Created by WSR on 16/07/2020.
//  Copyright © 2020 WSR. All rights reserved.
//

import UIKit

class TabBarViewController: UITabBarController {

    @IBOutlet weak var tabView: UITabBar!
    let color = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    override func viewDidLoad() {
        super.viewDidLoad()
        tabView.unselectedItemTintColor = #colorLiteral(red: 0.4271275699, green: 0.3164451122, blue: 0.702347219, alpha: 1)
      
    
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
