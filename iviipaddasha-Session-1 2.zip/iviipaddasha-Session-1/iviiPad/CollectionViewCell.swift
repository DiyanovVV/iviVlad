//
//  CollectionViewCell.swift
//  iviiPad
//
//  Created by WSR on 16/07/2020.
//  Copyright © 2020 WSR. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageFilm: UIImageView!
    @IBOutlet weak var nameFilm: UILabel!
    
    
}
