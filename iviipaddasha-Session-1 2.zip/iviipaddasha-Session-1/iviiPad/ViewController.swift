//
//  ViewController.swift
//  iviiPad
//
//  Created by WSR on 16/07/2020.
//  Copyright © 2020 WSR. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    
    @IBOutlet weak var serialColl: UICollectionView!
    @IBOutlet weak var multColl: UICollectionView!
    @IBOutlet weak var styleColl: UICollectionView!
    
    @IBOutlet weak var newColl: UICollectionView!
    @IBOutlet weak var triaImage: UIImageView!
    
    
    struct styleFilm {
        var image: String
        var name: String
    }
    
    let color = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    var films: [Film] = []
    var stylefilms: [styleFilm] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        triaImage.contentMode = .scaleAspectFill
        films = addFilm().add()
        addStyleFilm()
        // Do any additional setup after loading the view.
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == newColl {
            return films.count
        } else if collectionView == serialColl {
            return films.filter({$0.type == "Сериал"}).count
        } else if collectionView == multColl {
            return films.filter({$0.type == "Мультфильм"}).count
        } else if collectionView == styleColl {
            return stylefilms.count
        } else {
            return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        
        if collectionView == newColl {
            let f = films[indexPath.row]
            cell.imageFilm.image = UIImage(named: f.image)
            cell.nameFilm.text = f.name
        } else if collectionView == serialColl {
            cell.imageFilm.image = UIImage(named: films.filter({$0.type == "Сериал"})[indexPath.row].image)
            cell.nameFilm.text = films.filter({$0.type == "Сериал"})[indexPath.row].name
        } else if collectionView == multColl {
            cell.imageFilm.image = UIImage(named: films.filter({$0.type == "Мультфильм"})[indexPath.row].image)
            cell.nameFilm.text = films.filter({$0.type == "Мультфильм"})[indexPath.row].name
        } else if collectionView == styleColl {
            let sf = stylefilms[indexPath.row]
            cell.imageFilm.image = UIImage(named: sf.image)
            cell.nameFilm.text = sf.name
        }
        
        cell.imageFilm.contentMode = .scaleAspectFill
        
        // Configure the cell
        
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == multColl {
            return CGSize(width: 320, height: 220)
        } else if collectionView == styleColl {
            return CGSize(width: 140, height: 140)
        } else {
            return CGSize(width: 170, height: 210)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath) as! CollectionViewCell
        if collectionView == styleColl {
            UserDefaults.standard.set(cell.nameFilm.text, forKey: "styleFilm")
            performSegue(withIdentifier: "segStyle", sender: self)
        } else {
            UserDefaults.standard.set(cell.nameFilm.text, forKey: "nameFilm")
            performSegue(withIdentifier: "segFilm", sender: self)
        }
    }
    
    func addStyleFilm() {
        stylefilms.append(styleFilm(image: "icons8-экшн-100", name: "Экшн"))
        stylefilms.append(styleFilm(image: "icons8-драма-100", name: "Драма"))
        stylefilms.append(styleFilm(image: "icons8-инопланетянин-100", name: "Фантастика"))
        stylefilms.append(styleFilm(image: "icons8-комедия-100", name: "Комедия"))
        stylefilms.append(styleFilm(image: "icons8-ужастик-100", name: "Ужасы"))
        stylefilms.append(styleFilm(image: "icons8-усы-100", name: "Детектив"))
        stylefilms.append(styleFilm(image: "icons8-роман-100", name: "Мелодрама"))
    }
    
}

