//
//  StyleViewController.swift
//  iviiPad
//
//  Created by WSR on 17/07/2020.
//  Copyright © 2020 WSR. All rights reserved.
//

import UIKit
import  AlignedCollectionViewFlowLayout
class StyleViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UICollectionViewDataSource {
    
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var collView: UICollectionView!
    var films = addFilm().add().filter({$0.style == UserDefaults.standard.string(forKey: "styleFilm")})
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collView.collectionViewLayout = AlignedCollectionViewFlowLayout(horizontalAlignment: .justified, verticalAlignment: .top)
        titleLabel.text = UserDefaults.standard.string(forKey: "styleFilm")
        // Do any additional setup after loading the view.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return films.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        let f = films[indexPath.row]
        cell.imageFilm.image = UIImage(named: f.image)
        cell.nameFilm.text = f.name
        cell.imageFilm.contentMode = .scaleAspectFill
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
               return CGSize(width: 170, height: 230)
       }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath) as! CollectionViewCell
        UserDefaults.standard.set(cell.nameFilm.text, forKey: "nameFilm")
        performSegue(withIdentifier: "segFilm", sender: self)
    }
    
    @IBAction func backAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
}
